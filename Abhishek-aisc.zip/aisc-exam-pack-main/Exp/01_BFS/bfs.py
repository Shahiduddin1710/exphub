def make_graph(text):
    graph = {}
    for edge in text.split():
        a, b = edge.upper().split("-")
        graph.setdefault(a, []).append(b)
        graph.setdefault(b, []).append(a)
    return graph


def bfs(graph, start, goal):
    queue = [[start]]        # each item in the queue is a full path
    visited = [start]
    order = []

    while len(queue) > 0:
        path = queue.pop(0)
        node = path[-1]
        order.append(node)

        if node == goal:
            print("Visited order:", " ".join(order))
            print("Path:", " -> ".join(path))
            return

        for nxt in sorted(graph.get(node, [])):
            if nxt not in visited:
                visited.append(nxt)
                queue.append(path + [nxt])

    print("No path found")


graph = make_graph(input("Edges (like A-B A-C): "))
start = input("Start node: ").upper()
goal = input("Goal node: ").upper()
bfs(graph, start, goal)
