def make_graph(text):
    graph = {}
    for edge in text.split():
        a, b = edge.upper().split("-")
        graph.setdefault(a, []).append(b)
        graph.setdefault(b, []).append(a)
    return graph


def dfs(graph, start, goal):
    stack = [[start]]
    visited = []

    while len(stack) > 0:
        path = stack.pop()       # last in, first out
        node = path[-1]

        if node in visited:
            continue
        visited.append(node)

        if node == goal:
            print("Visited order:", " ".join(visited))
            print("Path:", " -> ".join(path))
            return

        # pushed in reverse so the alphabetically first neighbour comes out first
        for nxt in sorted(graph.get(node, []), reverse=True):
            if nxt not in visited:
                stack.append(path + [nxt])

    print("No path found")


graph = make_graph(input("Edges (like A-B A-C): "))
start = input("Start node: ").upper()
goal = input("Goal node: ").upper()
dfs(graph, start, goal)
