def make_graph(text):
    graph = {}
    for edge in text.split():
        a, b = edge.upper().split("-")
        graph.setdefault(a, []).append(b)
        graph.setdefault(b, []).append(a)
    return graph


def read_h(text):
    h = {}
    for item in text.split():
        name, value = item.upper().split("=")
        h[name] = int(value)
    return h


def greedy(graph, h, start, goal):
    open_list = [[h[start], [start]]]      # [h value, path]
    closed = []

    while len(open_list) > 0:
        open_list.sort()                   # smallest h first
        value, path = open_list.pop(0)
        node = path[-1]

        if node == goal:
            print("Path:", " -> ".join(path))
            return
        if node in closed:
            continue
        closed.append(node)

        for nxt in graph.get(node, []):
            if nxt not in closed:
                open_list.append([h[nxt], path + [nxt]])

    print("No path found")


graph = make_graph(input("Edges (like A-B A-C): "))
h = read_h(input("Heuristics (like A=6 B=4): "))
start = input("Start node: ").upper()
goal = input("Goal node: ").upper()
greedy(graph, h, start, goal)
