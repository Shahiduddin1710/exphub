def make_graph(text):
    graph = {}
    for item in text.split():
        edge, cost = item.upper().split(":")
        a, b = edge.split("-")
        graph.setdefault(a, []).append([b, int(cost)])
        graph.setdefault(b, []).append([a, int(cost)])
    return graph


def read_h(text):
    h = {}
    for item in text.split():
        name, value = item.upper().split("=")
        h[name] = int(value)
    return h


def astar(graph, h, start, goal):
    open_list = [[h[start], 0, [start]]]   # [f, g, path]   f = g + h
    best_g = {}

    while len(open_list) > 0:
        open_list.sort()                   # smallest f first
        f, g, path = open_list.pop(0)
        node = path[-1]

        if node == goal:
            print("Path:", " -> ".join(path), "| Cost:", g)
            return
        if node in best_g and best_g[node] <= g:
            continue
        best_g[node] = g

        for nxt, cost in graph.get(node, []):
            new_g = g + cost
            open_list.append([new_g + h[nxt], new_g, path + [nxt]])

    print("No path found")


graph = make_graph(input("Edges with cost (like A-B:2 A-C:3): "))
h = read_h(input("Heuristics (like A=5 B=4): "))
start = input("Start node: ").upper()
goal = input("Goal node: ").upper()
astar(graph, h, start, goal)
