data = [[0, 0, 0], [0, 1, 1], [1, 0, 1], [1, 1, 1]]     # x1, x2, target (OR)


def step(net):
    if net >= 0:
        return 1
    return 0


lr = float(input("Learning rate: "))
w1, w2, b = map(float, input("Initial w1 w2 bias: ").split())

epoch = 0
while epoch < 100:
    epoch += 1
    errors = 0

    for x1, x2, t in data:
        y = step(w1 * x1 + w2 * x2 + b)
        err = t - y

        # delta rule: w(new) = w(old) + lr * (t - y) * x
        w1 = round(w1 + lr * err * x1, 2)
        w2 = round(w2 + lr * err * x2, 2)
        b = round(b + lr * err, 2)

        if err != 0:
            errors += 1

    print("Epoch %d: w1=%.2f w2=%.2f b=%.2f errors=%d" % (epoch, w1, w2, b, errors))
    if errors == 0:
        break

if errors == 0:
    print("Converged at epoch %d | Final w1=%.2f, w2=%.2f, bias=%.2f" % (epoch, w1, w2, b))
else:
    print("Did not converge in 100 epochs")

print()
print("x1 x2  target  predicted")
for x1, x2, t in data:
    print(" %d  %d     %d        %d" % (x1, x2, t, step(w1 * x1 + w2 * x2 + b)))
