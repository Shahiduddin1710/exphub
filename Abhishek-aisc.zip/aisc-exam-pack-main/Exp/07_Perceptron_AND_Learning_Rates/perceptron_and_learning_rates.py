data = [[0, 0, 0], [0, 1, 0], [1, 0, 0], [1, 1, 1]]     # x1, x2, target (AND)


def step(net):
    if net >= 0:
        return 1
    return 0


def train(lr, w1, w2, b):
    epoch = 0
    while epoch < 100:
        epoch += 1
        errors = 0
        for x1, x2, t in data:
            err = t - step(w1 * x1 + w2 * x2 + b)
            w1 = round(w1 + lr * err * x1, 2)
            w2 = round(w2 + lr * err * x2, 2)
            b = round(b + lr * err, 2)
            if err != 0:
                errors += 1
        if errors == 0:
            break
    return epoch, w1, w2, b


w1, w2, b = map(float, input("Initial w1 w2 bias: ").split())

print()
print("Learning rate | Epochs | Final w1  w2  bias")
for lr in [0.1, 0.3, 0.5]:
    epochs, f1, f2, fb = train(lr, w1, w2, b)      # same starting weights every time
    print("     %.1f      |   %d    | %.2f  %.2f  %.2f" % (lr, epochs, f1, f2, fb))
