try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None

points = [[1, 1], [2, 1], [1, 2], [8, 8], [9, 8], [8, 9]]     # assumed input data
weights = [[3, 4], [5, 3]]                                   # W1, W2 (one neuron per cluster)


def dist(p, w):
    return (p[0] - w[0]) ** 2 + (p[1] - w[1]) ** 2


def r2(v):
    return round(v + 0.0000001, 2)      # 2 decimals, .5 always rounds up (same as on paper)


lr = float(input("Learning rate (alpha): "))
epochs = int(input("Epochs: "))

for ep in range(1, epochs + 1):
    print("\nEpoch", ep, " alpha =", lr)

    for p in points:
        d = [dist(p, w) for w in weights]
        win = d.index(min(d))

        # only the winner moves: w(new) = w(old) + alpha * (x - w(old))
        weights[win][0] = r2(weights[win][0] + lr * (p[0] - weights[win][0]))
        weights[win][1] = r2(weights[win][1] + lr * (p[1] - weights[win][1]))

        print("  x =", p, " D =", ", ".join("%.2f" % r2(v) for v in d),
              " winner W%d, new W%d =" % (win + 1, win + 1), weights[win])

    lr = lr / 2          # alpha(t+1) = 0.5 * alpha(t)

print("\nFinal weights:", weights)

groups = [[] for w in weights]
for p in points:
    d = [dist(p, w) for w in weights]
    groups[d.index(min(d))].append(p)

for i in range(len(groups)):
    print("Cluster %d:" % (i + 1), groups[i])

if plt is None:
    print("\nmatplotlib is not installed, so the graph is skipped (pip install matplotlib)")
else:
    colours = ["blue", "green", "orange", "purple"]
    for i in range(len(groups)):
        for p in groups[i]:
            plt.scatter(p[0], p[1], color=colours[i], s=80)
        plt.scatter(weights[i][0], weights[i][1], color="red", marker="X", s=200)
    plt.title("Kohonen SOM clusters (red X = neuron weights)")
    plt.xlabel("x1")
    plt.ylabel("x2")
    plt.grid(True)
    plt.show()
