import math

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None


def triangular(x, a, b, c):
    if x <= a or x >= c:
        return 0
    if x <= b:
        return (x - a) / (b - a)
    return (c - x) / (c - b)


def trapezoidal(x, a, b, c, d):
    if x <= a or x >= d:
        return 0
    if x < b:
        return (x - a) / (b - a)
    if x <= c:
        return 1
    return (d - x) / (d - c)


def gaussian(x, m, s):
    return math.exp(-(x - m) ** 2 / (2 * s ** 2))


names = ["Lightly Soiled", "Moderately Soiled", "Heavily Soiled"]
tri = [(-50, 0, 50), (0, 50, 100), (50, 100, 150)]
trap = [(-10, 0, 20, 40), (20, 40, 60, 80), (60, 80, 100, 110)]
gauss = [(0, 20), (50, 15), (100, 20)]

funcs = [["Triangular", triangular, tri],
         ["Trapezoidal", trapezoidal, trap],
         ["Gaussian", gaussian, gauss]]

x = float(input("Dirt level in % (0-100): "))

for title, f, params in funcs:
    print()
    print(title, "memberships at", x)
    for i in range(3):
        print("  %s: %.2f" % (names[i], f(x, *params[i])))

if plt is None:
    print("\nmatplotlib is not installed, so the graph is skipped (pip install matplotlib)")
else:
    xs = [i / 2 for i in range(201)]          # 0 to 100
    plt.figure(figsize=(15, 4))
    for n in range(3):
        title, f, params = funcs[n]
        plt.subplot(1, 3, n + 1)
        for i in range(3):
            plt.plot(xs, [f(v, *params[i]) for v in xs], label=names[i])
        plt.axvline(x, color="gray", linestyle="--")
        plt.title(title)
        plt.xlabel("Dirt level (%)")
        plt.ylabel("Membership")
        plt.legend()
        plt.grid(True)
    plt.tight_layout()
    plt.show()
