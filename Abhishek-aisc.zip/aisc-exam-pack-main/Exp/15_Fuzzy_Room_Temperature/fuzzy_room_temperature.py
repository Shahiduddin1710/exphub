import math

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None


def triangular(x, a, b, c):
    if x <= a or x >= c:
        return 0
    if x <= b:
        return (x - a) / (b - a)
    return (c - x) / (c - b)


def trapezoidal(x, a, b, c, d):
    if x <= a or x >= d:
        return 0
    if x < b:
        return (x - a) / (b - a)
    if x <= c:
        return 1
    return (d - x) / (d - c)


def gaussian(x, m, s):
    return math.exp(-(x - m) ** 2 / (2 * s ** 2))


names = ["Cold", "Comfortable", "Hot"]
tri = [(-10, 0, 20), (10, 22, 34), (24, 40, 56)]
trap = [(-10, 0, 10, 20), (15, 20, 26, 31), (26, 32, 45, 50)]
gauss = [(5, 6), (22, 4), (38, 6)]

funcs = [["Triangular", triangular, tri],
         ["Trapezoidal", trapezoidal, trap],
         ["Gaussian", gaussian, gauss]]

x = float(input("Room temperature in C (0-40): "))

for title, f, params in funcs:
    print()
    print(title, "memberships at", x)
    for i in range(3):
        print("  %s: %.2f" % (names[i], f(x, *params[i])))

if plt is None:
    print("\nmatplotlib is not installed, so the graph is skipped (pip install matplotlib)")
else:
    xs = [i / 10 for i in range(401)]         # 0 to 40
    plt.figure(figsize=(15, 4))
    for n in range(3):
        title, f, params = funcs[n]
        plt.subplot(1, 3, n + 1)
        for i in range(3):
            plt.plot(xs, [f(v, *params[i]) for v in xs], label=names[i])
        plt.axvline(x, color="gray", linestyle="--")
        plt.title(title)
        plt.xlabel("Temperature (C)")
        plt.ylabel("Membership")
        plt.legend()
        plt.grid(True)
    plt.tight_layout()
    plt.show()
