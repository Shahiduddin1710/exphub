import math

try:
    import matplotlib.pyplot as plt
except ImportError:
    plt = None


def triangular(x, a, b, c):
    if x <= a or x >= c:
        return 0
    if x <= b:
        return (x - a) / (b - a)
    return (c - x) / (c - b)


def trapezoidal(x, a, b, c, d):
    if x <= a or x >= d:
        return 0
    if x < b:
        return (x - a) / (b - a)
    if x <= c:
        return 1
    return (d - x) / (d - c)


def gaussian(x, m, s):
    return math.exp(-(x - m) ** 2 / (2 * s ** 2))


names = ["Low", "Medium", "High"]
tri = [(-30, 0, 30), (10, 30, 50), (30, 60, 90)]
trap = [(-10, 0, 10, 25), (15, 25, 35, 45), (35, 50, 60, 70)]
gauss = [(0, 10), (30, 8), (60, 10)]

funcs = [["Triangular", triangular, tri],
         ["Trapezoidal", trapezoidal, trap],
         ["Gaussian", gaussian, gauss]]

x = float(input("Traffic density in vehicles/min (0-60): "))

for title, f, params in funcs:
    print()
    print(title, "memberships at", x)
    for i in range(3):
        print("  %s: %.2f" % (names[i], f(x, *params[i])))

if plt is None:
    print("\nmatplotlib is not installed, so the graph is skipped (pip install matplotlib)")
else:
    xs = [i / 10 for i in range(601)]         # 0 to 60
    plt.figure(figsize=(15, 4))
    for n in range(3):
        title, f, params = funcs[n]
        plt.subplot(1, 3, n + 1)
        for i in range(3):
            plt.plot(xs, [f(v, *params[i]) for v in xs], label=names[i])
        plt.axvline(x, color="gray", linestyle="--")
        plt.title(title)
        plt.xlabel("Traffic density (vehicles/min)")
        plt.ylabel("Membership")
        plt.legend()
        plt.grid(True)
    plt.tight_layout()
    plt.show()
