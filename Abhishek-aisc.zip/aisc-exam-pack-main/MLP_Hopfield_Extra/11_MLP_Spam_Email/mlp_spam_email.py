import math

data = [[0, 0, 0], [0, 1, 0], [1, 0, 0], [1, 1, 1]]     # x1, x2, target

# starting weights (change these if the paper gives other values)
v = [[0.2, -0.3],
     [0.4, 0.1]]        # v[i][j] = input i -> hidden j
bh = [0.1, -0.2]       # hidden biases
w = [0.3, -0.2]        # hidden -> output
bo = 0.1       # output bias

labels = ["Class 0 = Not Spam", "Class 1 = Spam"]


def sigmoid(x):
    return 1 / (1 + math.exp(-x))


def forward(x1, x2):
    h = []
    for j in range(len(bh)):
        h.append(sigmoid(bh[j] + x1 * v[0][j] + x2 * v[1][j]))
    net = bo
    for j in range(len(h)):
        net += h[j] * w[j]
    return h, sigmoid(net)


lr = float(input("Learning rate: "))
epochs = int(input("Epochs: "))

for ep in range(1, epochs + 1):
    total_error = 0

    for k in range(len(data)):
        x1, x2, t = data[k]
        h, y = forward(x1, x2)

        # back propagation of the error
        dy = (t - y) * y * (1 - y)
        dh = [dy * w[j] * h[j] * (1 - h[j]) for j in range(len(h))]

        for j in range(len(h)):
            w[j] += lr * dy * h[j]
            v[0][j] += lr * dh[j] * x1
            v[1][j] += lr * dh[j] * x2
            bh[j] += lr * dh[j]
        bo += lr * dy
        total_error += (t - y) ** 2

        if ep == 1:                         # show every step of epoch 1 (to check the hand calculation)
            print("\nEpoch 1, pattern %d  (x1=%d x2=%d target=%d)" % (k + 1, x1, x2, t))
            print("  h =", " ".join("%.4f" % a for a in h), "  y = %.4f  error = %.4f" % (y, t - y))
            print("  delta_out = %.4f  delta_hidden =" % dy, " ".join("%.4f" % a for a in dh))
            print("  new v1 =", " ".join("%.4f" % a for a in v[0]), "  new v2 =", " ".join("%.4f" % a for a in v[1]))
            print("  new hidden bias =", " ".join("%.4f" % a for a in bh))
            print("  new w =", " ".join("%.4f" % a for a in w), "  new output bias = %.4f" % bo)

    if ep == 1:
        print()
    if ep == 1 or ep % max(1, epochs // 5) == 0:
        print("Epoch %d  total error = %.4f" % (ep, total_error))

print("\nAfter training:")
print("x1 x2  target  output  class")
for x1, x2, t in data:
    h, y = forward(x1, x2)
    print(" %d  %d    %d     %.3f    %d" % (x1, x2, t, y, 1 if y >= 0.5 else 0))

a, b = map(int, input("\nTest input x1 x2: ").split())
h, y = forward(a, b)
c = 1 if y >= 0.5 else 0
print("Output = %.3f  ->  %s" % (y, labels[c]))
