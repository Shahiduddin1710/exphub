def read(text):
    return [int(v) for v in text.split()]


count = int(input("How many patterns to store: "))
patterns = []
for k in range(count):
    patterns.append(read(input("Pattern %d (like 1 -1 1 -1 1 -1): " % (k + 1))))
n = len(patterns[0])

# Hebbian learning: W = sum of p * p(transpose), with 0 on the diagonal
W = [[0] * n for i in range(n)]
for p in patterns:
    for i in range(n):
        for j in range(n):
            if i != j:
                W[i][j] += p[i] * p[j]

print("\nWeight matrix W:")
for row in W:
    print("  " + " ".join("%3d" % a for a in row))

x = read(input("\nNoisy test pattern: "))
print("\nStart:", x)

changed = True
rnd = 0
while changed:
    changed = False
    rnd += 1
    for i in range(n):              # update one neuron at a time (asynchronous)
        net = 0
        for j in range(n):
            net += W[i][j] * x[j]

        new = x[i]
        if net > 0:
            new = 1
        elif net < 0:
            new = -1

        if new != x[i]:
            changed = True
        x[i] = new
        print("  round %d  neuron %d: net = %3d  ->  %2d" % (rnd, i + 1, net, new))
    print("After round %d:" % rnd, x)

print("\nRecalled pattern:", x)
found = False
for k in range(count):
    if x == patterns[k]:
        print("It matches stored pattern %d, so the pattern was recalled successfully" % (k + 1))
        found = True
if not found:
    print("It does not match any stored pattern")
