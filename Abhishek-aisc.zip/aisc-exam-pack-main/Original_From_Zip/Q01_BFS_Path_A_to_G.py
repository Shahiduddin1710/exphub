# Q1: Breadth First Search (BFS) - find path from Start node to Goal node

# Step 1: make the graph from the edges typed by the user
def make_graph(text):
    graph = {}
    for edge in text.split():          # edge looks like "A-B"
        a, b = edge.upper().split('-')
        if a not in graph: graph[a] = []
        if b not in graph: graph[b] = []
        graph[a].append(b)             # undirected, so add both ways
        graph[b].append(a)
    return graph

# Step 2: BFS using a queue (first in, first out)
def bfs(graph, start, goal):
    queue = [[start]]                  # queue stores paths
    visited = [start]
    order = []
    while len(queue) > 0:
        path = queue.pop(0)            # take the FIRST path
        node = path[-1]                # last node of that path
        order.append(node)
        if node == goal:
            print("Visited order:", ' '.join(order))
            print("Path:", ' -> '.join(path))
            return
        for next_node in sorted(graph[node]):
            if next_node not in visited:
                visited.append(next_node)
                queue.append(path + [next_node])
    print("No path found")

graph = make_graph(input("Edges: "))
start = input("Start: ").upper()
goal = input("Goal: ").upper()
bfs(graph, start, goal)


# Q1: BFS (Start A, Goal G)
# Input format: edges as A-B A-C ... (undirected, no spaces inside an edge)
# Example Input:
#   Edges: A-B A-D A-E B-C B-E C-E C-F C-G D-E E-F F-G
#   Start: A
#   Goal: G
# Example Output:
#   Visited order: A B D E C F G
#   Path: A -> B -> C -> G


# ======================================================================
# SOLUTION (step-by-step manual working) - Q1: Breadth First Search (BFS) – A to G
# ======================================================================
#
# Given:
#   - Start node = A, Goal node = G
#   - BFS uses a QUEUE (FIFO – First In First Out)
#   - BFS explores all neighbours of a node (one level) before going to the next level
#
# Adjacency list (from the graph):
#   +------+----------------+
#   | Node | Adjacent nodes |
#   +------+----------------+
#   | A    | B, D, E        |
#   | B    | A, C, E        |
#   | C    | B, E, F, G     |
#   | D    | A, E           |
#   | E    | A, B, C, D, F  |
#   | F    | C, E, G        |
#   | G    | C, F           |
#   +------+----------------+
#
# Step-by-step working:
#   +------+---------------------------+-------------------------------------+------------------+
#   | Step | Visit & delete from queue | Adjacent nodes not visited (insert) | Queue after step |
#   +------+---------------------------+-------------------------------------+------------------+
#   | 1    | – (start)                 | Insert A                            | [A]              |
#   | 2    | A                         | B, D, E                             | [B, D, E]        |
#   | 3    | B                         | C                                   | [D, E, C]        |
#   | 4    | D                         | none                                | [E, C]           |
#   | 5    | E                         | F                                   | [C, F]           |
#   | 6    | C                         | G                                   | [F, G]           |
#   | 7    | F                         | none                                | [G]              |
#   | 8    | G                         | G = Goal → STOP                     | [ ]              |
#   +------+---------------------------+-------------------------------------+------------------+
#
# Finding the path (go back using parent of each node):
#   - Parents: B←A, D←A, E←A, C←B, F←E, G←C
#   - G ← C ← B ← A, so Path = A → B → C → G
#
# Result:
#   - Visited order: A B D E C F G
#   - Path: A → B → C → G (3 edges)
#   (Diagram: BFS graph: #number = visit order, red = final path - see Google Doc)
# ======================================================================
