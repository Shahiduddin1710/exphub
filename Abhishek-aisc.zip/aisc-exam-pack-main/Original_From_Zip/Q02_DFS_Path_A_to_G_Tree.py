# Q2: Depth First Search (DFS) - find path from Start node to Goal node

# Step 1: make the graph from the edges typed by the user
def make_graph(text):
    graph = {}
    for edge in text.split():          # edge looks like "A-B"
        a, b = edge.upper().split('-')
        if a not in graph: graph[a] = []
        if b not in graph: graph[b] = []
        graph[a].append(b)             # undirected, so add both ways
        graph[b].append(a)
    return graph

# Step 2: DFS using a stack (last in, first out)
def dfs(graph, start, goal):
    stack = [[start]]                  # stack stores paths
    order = []
    while len(stack) > 0:
        path = stack.pop()             # take the LAST path
        node = path[-1]
        if node in order:
            continue                   # already visited, skip it
        order.append(node)
        if node == goal:
            print("Visited order:", ' '.join(order))
            print("Path:", ' -> '.join(path))
            return
        # push in reverse so that A, B, C... are explored left to right
        for next_node in sorted(graph[node], reverse=True):
            if next_node not in order:
                stack.append(path + [next_node])
    print("No path found")

graph = make_graph(input("Edges: "))
start = input("Start: ").upper()
goal = input("Goal: ").upper()
dfs(graph, start, goal)


# Q2: DFS (Start A, Goal G)
# Input format: edges as A-B A-C ... (undirected, no spaces inside an edge)
# Example Input:
#   Edges: A-B A-C B-D B-E E-H C-F C-G
#   Start: A
#   Goal: G
# Example Output:
#   Visited order: A B D E H C F G
#   Path: A -> C -> G


# ======================================================================
# SOLUTION (step-by-step manual working) - Q2: Depth First Search (DFS) – A to G (Tree)
# ======================================================================
#
# Given:
#   - Start node = A, Goal node = G
#   - DFS uses a STACK (LIFO – Last In First Out)
#   - DFS goes deep along one branch first, then backtracks
#
# Adjacency list (from the tree):
#   +------+----------------+
#   | Node | Adjacent nodes |
#   +------+----------------+
#   | A    | B, C           |
#   | B    | A, D, E        |
#   | C    | A, F, G        |
#   | D    | B              |
#   | E    | B, H           |
#   | F    | C              |
#   | G    | C              |
#   | H    | E              |
#   +------+----------------+
#
# Step-by-step working (stack written bottom → top):
#   +------+---------------------------------------------------------+--------------+-----------------+
#   | Step | Action                                                  | Stack        | Visited         |
#   +------+---------------------------------------------------------+--------------+-----------------+
#   | 1    | Push A (start)                                          | [A]          | A               |
#   | 2    | Adjacent of A not visited = B → push B                  | [A, B]       | A B             |
#   | 3    | Adjacent of B not visited = D → push D                  | [A, B, D]    | A B D           |
#   | 4    | D has no unvisited node → pop D (backtrack)             | [A, B]       | A B D           |
#   | 5    | Adjacent of B not visited = E → push E                  | [A, B, E]    | A B D E         |
#   | 6    | Adjacent of E not visited = H → push H                  | [A, B, E, H] | A B D E H       |
#   | 7    | H has no unvisited node → pop H                         | [A, B, E]    | A B D E H       |
#   | 8    | E has no unvisited node → pop E                         | [A, B]       | A B D E H       |
#   | 9    | B has no unvisited node → pop B                         | [A]          | A B D E H       |
#   | 10   | Adjacent of A not visited = C → push C                  | [A, C]       | A B D E H C     |
#   | 11   | Adjacent of C not visited = F → push F                  | [A, C, F]    | A B D E H C F   |
#   | 12   | F has no unvisited node → pop F                         | [A, C]       | A B D E H C F   |
#   | 13   | Adjacent of C not visited = G → push G. G = Goal → STOP | [A, C, G]    | A B D E H C F G |
#   +------+---------------------------------------------------------+--------------+-----------------+
#
# Result:
#   - Visited order: A B D E H C F G
#   - Path = nodes left in the stack = A → C → G
#   (Diagram: DFS tree: #number = visit order, red = final path - see Google Doc)
# ======================================================================
