# Q6: Single Layer Perceptron using Delta Rule - OR gate

# Truth table of OR gate: [x1, x2, target]
data = [[0, 0, 0], [0, 1, 1], [1, 0, 1], [1, 1, 1]]

# Step function: output is 1 if net >= 0, else 0
def step(net):
    if net >= 0:
        return 1
    return 0

lr = float(input("Learning rate: "))
w1, w2, b = input("Initial w1 w2 bias: ").split()
w1, w2, b = float(w1), float(w2), float(b)

epoch = 0
while True:
    epoch = epoch + 1
    errors = 0
    for x1, x2, target in data:
        net = w1*x1 + w2*x2 + b
        output = step(net)
        error = target - output
        # Delta rule: new weight = old weight + lr * error * input
        w1 = round(w1 + lr*error*x1, 2)
        w2 = round(w2 + lr*error*x2, 2)
        b = round(b + lr*error, 2)
        if error != 0:
            errors = errors + 1
    print(f"Epoch {epoch}: w1={w1:.2f} w2={w2:.2f} b={b:.2f} errors={errors}")
    if errors == 0 or epoch == 100:    # stop when no mistakes
        break

print(f"Converged at epoch {epoch} | Final w1={w1:.2f}, w2={w2:.2f}, bias={b:.2f}")
print("x1 x2 target predicted")
for x1, x2, target in data:
    print(f" {x1}  {x2}    {target}       {step(w1*x1 + w2*x2 + b)}")


# Q6: SLP Delta Rule - OR gate (run again with a different learning rate to experiment)
# Example Input:
#   Learning rate: 0.1
#   Initial w1 w2 bias: 0.1 0.1 0.1
# Example Output:
#   Epoch 1: w1=0.10 w2=0.10 b=0.00 errors=1
#   Epoch 2: w1=0.10 w2=0.10 b=-0.10 errors=1
#   Epoch 3: w1=0.10 w2=0.10 b=-0.10 errors=0
#   Converged at epoch 3 | Final w1=0.10, w2=0.10, bias=-0.10
#   x1 x2 target predicted
#    0  0    0       0
#    0  1    1       1
#    1  0    1       1
#    1  1    1       1


# ======================================================================
# SOLUTION (step-by-step manual working) - Q6: Perceptron (Delta Rule) – OR Gate
# ======================================================================
#
# Given:
#   - OR gate (binary inputs and targets)
#   - Learning rate α = 0.1
#   - Initial weights: w1 = 0.1, w2 = 0.1, bias b = 0.1
#   +----+----+--------+
#   | x1 | x2 | t (OR) |
#   +----+----+--------+
#   | 0  | 0  | 0      |
#   | 0  | 1  | 1      |
#   | 1  | 0  | 1      |
#   | 1  | 1  | 1      |
#   +----+----+--------+
#
# Formulas used:
#   - Net input: yin = b + x1·w1 + x2·w2
#   - Activation (binary step, θ = 0): y = 1 if yin ≥ 0, else y = 0
#   - Error = t − y  (t = target)
#   - Delta rule: Δw1 = α(t − y)x1,  Δw2 = α(t − y)x2,  Δb = α(t − y)
#   - New weight: w(new) = w(old) + Δw,  b(new) = b(old) + Δb
#   - If y = t → error 0 → no change in weights
#   - Stop when one full epoch has no error
#
# Sample calculation (Epoch 1, input 0 0):
#   - yin = 0.1 + 0(0.1) + 0(0.1) = 0.1 → y = 1
#   - t − y = 0 − 1 = −1 (error)
#   - Δb = 0.1 × (−1) = −0.1 → b = 0.0 (w1, w2 unchanged as x1 = x2 = 0)
#
# Training table (all epochs):
#   +----+----+----+---+-------+---+-----+------+------+-------+------+------+-------+
#   | Ep | x1 | x2 | t | yin   | y | t−y | Δw1  | Δw2  | Δb    | w1   | w2   | b     |
#   +----+----+----+---+-------+---+-----+------+------+-------+------+------+-------+
#   | 1  | 0  | 0  | 0 | 0.10  | 1 | -1  | 0.00 | 0.00 | -0.10 | 0.10 | 0.10 | 0.00  |
#   | 1  | 0  | 1  | 1 | 0.10  | 1 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | 0.00  |
#   | 1  | 1  | 0  | 1 | 0.10  | 1 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | 0.00  |
#   | 1  | 1  | 1  | 1 | 0.20  | 1 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | 0.00  |
#   | 2  | 0  | 0  | 0 | 0.00  | 1 | -1  | 0.00 | 0.00 | -0.10 | 0.10 | 0.10 | -0.10 |
#   | 2  | 0  | 1  | 1 | 0.00  | 1 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | -0.10 |
#   | 2  | 1  | 0  | 1 | 0.00  | 1 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | -0.10 |
#   | 2  | 1  | 1  | 1 | 0.10  | 1 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | -0.10 |
#   | 3  | 0  | 0  | 0 | -0.10 | 0 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | -0.10 |
#   | 3  | 0  | 1  | 1 | 0.00  | 1 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | -0.10 |
#   | 3  | 1  | 0  | 1 | 0.00  | 1 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | -0.10 |
#   | 3  | 1  | 1  | 1 | 0.10  | 1 | 0   | 0.00 | 0.00 | 0.00  | 0.10 | 0.10 | -0.10 |
#   +----+----+----+---+-------+---+-----+------+------+-------+------+------+-------+
#
# Errors per epoch:
#   +-------+---------------+------+------+-------+
#   | Epoch | No. of errors | w1   | w2   | b     |
#   +-------+---------------+------+------+-------+
#   | 1     | 1             | 0.10 | 0.10 | 0.00  |
#   | 2     | 1             | 0.10 | 0.10 | -0.10 |
#   | 3     | 0             | 0.10 | 0.10 | -0.10 |
#   +-------+---------------+------+------+-------+
#
# Convergence check: predicted vs target:
#   +----+----+-----------------------------------+---+---+---------+
#   | x1 | x2 | yin = b + x1·w1 + x2·w2           | y | t | y = t ? |
#   +----+----+-----------------------------------+---+---+---------+
#   | 0  | 0  | -0.10 + 0(0.10) + 0(0.10) = -0.10 | 0 | 0 | ✓       |
#   | 0  | 1  | -0.10 + 0(0.10) + 1(0.10) = 0.00  | 1 | 1 | ✓       |
#   | 1  | 0  | -0.10 + 1(0.10) + 0(0.10) = 0.00  | 1 | 1 | ✓       |
#   | 1  | 1  | -0.10 + 1(0.10) + 1(0.10) = 0.10  | 1 | 1 | ✓       |
#   +----+----+-----------------------------------+---+---+---------+
#
# Result:
#   - Converged at epoch 3
#   - Final weights: w1 = 0.10, w2 = 0.10, bias b = -0.10
#   - Predicted output = target output for all 4 inputs, so the network has converged
#   - Run again with another α (e.g. 0.3, 0.5) to experiment with the learning rate
#   (Diagram: Final OR perceptron - see Google Doc)
# ======================================================================
