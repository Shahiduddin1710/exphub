# Q7: AND gate perceptron - compare learning rates 0.1, 0.3 and 0.5

# Truth table of AND gate: [x1, x2, target]
data = [[0, 0, 0], [0, 1, 0], [1, 0, 0], [1, 1, 1]]

# Step function: output is 1 if net >= 0, else 0
def step(net):
    if net >= 0:
        return 1
    return 0

# Train with one learning rate and return epochs and final weights
def train(lr, w1, w2, b):
    epoch = 0
    while True:
        epoch = epoch + 1
        errors = 0
        for x1, x2, target in data:
            error = target - step(w1*x1 + w2*x2 + b)
            # Delta rule: new weight = old weight + lr * error * input
            w1 = round(w1 + lr*error*x1, 2)
            w2 = round(w2 + lr*error*x2, 2)
            b = round(b + lr*error, 2)
            if error != 0:
                errors = errors + 1
        if errors == 0 or epoch == 100:   # stop when no mistakes
            return epoch, w1, w2, b

w1, w2, b = input("Initial w1 w2 bias: ").split()
w1, w2, b = float(w1), float(w2), float(b)

# same starting weights for every learning rate
for lr in [0.1, 0.3, 0.5]:
    epochs, f1, f2, fb = train(lr, w1, w2, b)
    print(f"lr={lr}: epochs={epochs}, w1={f1:.2f}, w2={f2:.2f}, bias={fb:.2f}")


# Q7: AND gate, learning rates 0.1 / 0.3 / 0.5 (same initial weights for all)
# Example Input:
#   Initial w1 w2 bias: 0.3 0.2 -0.1
# Example Output:
#   lr=0.1: epochs=2, w1=0.20, w2=0.10, bias=-0.30
#   lr=0.3: epochs=5, w1=0.60, w2=0.20, bias=-0.70
#   lr=0.5: epochs=8, w1=1.30, w2=0.70, bias=-1.60
# Analysis: the number of epochs depends on BOTH the learning rate and the initial weights.
# A large lr takes big weight jumps, so it can overshoot and needs more epochs to settle.
# A small lr takes small steady steps - here the starting weights were already close,
# so lr=0.1 converged fastest. If the weights start far away, a small lr can be slower.


# ======================================================================
# SOLUTION (step-by-step manual working) - Q7: AND Gate – Learning Rate Comparison
# ======================================================================
#
# Given:
#   - AND gate, same training patterns for all runs
#   - Same initial weights for all runs: w1 = 0.3, w2 = 0.2, b = −0.1
#   - Learning rates α = 0.1, 0.3, 0.5
#
# Formulas used:
#   - Net input: yin = b + x1·w1 + x2·w2
#   - Activation (binary step, θ = 0): y = 1 if yin ≥ 0, else y = 0
#   - Error = t − y  (t = target)
#   - Delta rule: Δw1 = α(t − y)x1,  Δw2 = α(t − y)x2,  Δb = α(t − y)
#   - New weight: w(new) = w(old) + Δw,  b(new) = b(old) + Δb
#   - If y = t → error 0 → no change in weights
#   - Stop when one full epoch has no error
#
# Training with α = 0.1 (full table):
#   +----+----+----+---+-------+---+-----+-------+-------+-------+------+------+-------+
#   | Ep | x1 | x2 | t | yin   | y | t−y | Δw1   | Δw2   | Δb    | w1   | w2   | b     |
#   +----+----+----+---+-------+---+-----+-------+-------+-------+------+------+-------+
#   | 1  | 0  | 0  | 0 | -0.10 | 0 | 0   | 0.00  | 0.00  | 0.00  | 0.30 | 0.20 | -0.10 |
#   | 1  | 0  | 1  | 0 | 0.10  | 1 | -1  | 0.00  | -0.10 | -0.10 | 0.30 | 0.10 | -0.20 |
#   | 1  | 1  | 0  | 0 | 0.10  | 1 | -1  | -0.10 | 0.00  | -0.10 | 0.20 | 0.10 | -0.30 |
#   | 1  | 1  | 1  | 1 | 0.00  | 1 | 0   | 0.00  | 0.00  | 0.00  | 0.20 | 0.10 | -0.30 |
#   | 2  | 0  | 0  | 0 | -0.30 | 0 | 0   | 0.00  | 0.00  | 0.00  | 0.20 | 0.10 | -0.30 |
#   | 2  | 0  | 1  | 0 | -0.20 | 0 | 0   | 0.00  | 0.00  | 0.00  | 0.20 | 0.10 | -0.30 |
#   | 2  | 1  | 0  | 0 | -0.10 | 0 | 0   | 0.00  | 0.00  | 0.00  | 0.20 | 0.10 | -0.30 |
#   | 2  | 1  | 1  | 1 | 0.00  | 1 | 0   | 0.00  | 0.00  | 0.00  | 0.20 | 0.10 | -0.30 |
#   +----+----+----+---+-------+---+-----+-------+-------+-------+------+------+-------+
#
# Training with α = 0.3 (end of each epoch):
#   +-------+---------------+------+------+-------+
#   | Epoch | No. of errors | w1   | w2   | b     |
#   +-------+---------------+------+------+-------+
#   | 1     | 2             | 0.60 | 0.20 | -0.10 |
#   | 2     | 3             | 0.60 | 0.20 | -0.40 |
#   | 3     | 2             | 0.60 | 0.50 | -0.40 |
#   | 4     | 1             | 0.60 | 0.20 | -0.70 |
#   | 5     | 0             | 0.60 | 0.20 | -0.70 |
#   +-------+---------------+------+------+-------+
#
# Training with α = 0.5 (end of each epoch):
#   +-------+---------------+------+------+-------+
#   | Epoch | No. of errors | w1   | w2   | b     |
#   +-------+---------------+------+------+-------+
#   | 1     | 2             | 0.80 | 0.20 | -0.10 |
#   | 2     | 3             | 0.80 | 0.20 | -0.60 |
#   | 3     | 2             | 0.80 | 0.70 | -0.60 |
#   | 4     | 2             | 1.30 | 0.70 | -0.60 |
#   | 5     | 3             | 1.30 | 0.70 | -1.10 |
#   | 6     | 2             | 1.30 | 1.20 | -1.10 |
#   | 7     | 1             | 1.30 | 0.70 | -1.60 |
#   | 8     | 0             | 1.30 | 0.70 | -1.60 |
#   +-------+---------------+------+------+-------+
#
# Comparison:
#   +-----------------+--------------------+----------+----------+---------+
#   | Learning rate α | Epochs to converge | Final w1 | Final w2 | Final b |
#   +-----------------+--------------------+----------+----------+---------+
#   | 0.1             | 2                  | 0.20     | 0.10     | -0.30   |
#   | 0.3             | 5                  | 0.60     | 0.20     | -0.70   |
#   | 0.5             | 8                  | 1.30     | 0.70     | -1.60   |
#   +-----------------+--------------------+----------+----------+---------+
#   (Diagram: Epochs needed for each learning rate - see Google Doc)
#
# Analysis:
#   - Learning rate α tells the network how much the weight should change during learning
#   - Small α (0.1): small steady steps; here starting weights were already close, so it converged fastest (2 epochs)
#   - Large α (0.5): big weight jumps, overshoots the correct weights, so it needed more epochs (8)
#   - Number of epochs depends on both α and the initial weights
# ======================================================================
