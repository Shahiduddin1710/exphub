# Q9: Fuzzy membership functions - Washing machine
import math
import matplotlib.pyplot as plt

# Triangular: rises from a to b, falls from b to c
def triangular(x, p):
    a, b, c = p
    if x <= a or x >= c:
        return 0
    elif x <= b:
        return (x - a) / (b - a)
    else:
        return (c - x) / (c - b)

# Trapezoidal: rises a to b, flat (=1) b to c, falls c to d
def trapezoidal(x, p):
    a, b, c, d = p
    if x <= a or x >= d:
        return 0
    elif x < b:
        return (x - a) / (b - a)
    elif x <= c:
        return 1
    else:
        return (d - x) / (d - c)

# Gaussian: bell curve with centre m and width s
def gaussian(x, p):
    m, s = p
    return math.exp(-((x - m)**2) / (2 * s**2))

# Assumed values for each level
names = ["Lightly Soiled", "Moderately Soiled", "Heavily Soiled"]
tri_values = [[-50, 0, 50], [0, 50, 100], [50, 100, 150]]
trap_values = [[-10, 0, 20, 40], [20, 40, 60, 80], [60, 80, 100, 110]]
gauss_values = [[0, 20], [50, 15], [100, 20]]

value = float(input("Enter Dirt level (%) (0-100): "))

print("\nTriangular memberships at", value)
for i in range(3):
    print(f"  {names[i]}: {triangular(value, tri_values[i]):.2f}")
print("\nTrapezoidal memberships at", value)
for i in range(3):
    print(f"  {names[i]}: {trapezoidal(value, trap_values[i]):.2f}")
print("\nGaussian memberships at", value)
for i in range(3):
    print(f"  {names[i]}: {gaussian(value, gauss_values[i]):.2f}")

# Plot all three types side by side
x_list = []
x = 0
while x <= 100:
    x_list.append(x)
    x = x + 0.5

titles = ["Triangular", "Trapezoidal", "Gaussian"]
plt.figure(figsize=(15, 4))
for n in range(3):
    plt.subplot(1, 3, n + 1)
    for i in range(3):
        y_list = []
        for x in x_list:
            if n == 0:
                y_list.append(triangular(x, tri_values[i]))
            elif n == 1:
                y_list.append(trapezoidal(x, trap_values[i]))
            else:
                y_list.append(gaussian(x, gauss_values[i]))
        plt.plot(x_list, y_list, label=names[i])
    plt.title(titles[n]); plt.xlabel("Dirt level (%)"); plt.ylabel("Membership")
    plt.legend(); plt.grid(True)
plt.tight_layout()
plt.show()

#python -m pip install matplotlib
# Q9: Fuzzy membership - Washing machine
# Example Input:   Enter Dirt level (%) (0-100): 30
# Example Output:
#   Triangular memberships at 30.0
#     Lightly Soiled: 0.40
#     Moderately Soiled: 0.60
#     Heavily Soiled: 0.00
#
#   Trapezoidal memberships at 30.0
#     Lightly Soiled: 0.50
#     Moderately Soiled: 0.50
#     Heavily Soiled: 0.00
#
#   Gaussian memberships at 30.0
#     Lightly Soiled: 0.32
#     Moderately Soiled: 0.41
#     Heavily Soiled: 0.00
# (also opens a window with 3 plots)


# ======================================================================
# SOLUTION (step-by-step manual working) - Q9: Fuzzy Membership – Washing Machine
# ======================================================================
#
# Given (assumed values):
#   - Input: Dirt level (%), x = 30
#   - Membership value μ(x) is always between 0 and 1
#   +-------------------+----------------------+--------------------------+-----------------+
#   | Fuzzy set         | Triangular (a, b, c) | Trapezoidal (a, b, c, d) | Gaussian (c, σ) |
#   +-------------------+----------------------+--------------------------+-----------------+
#   | Lightly Soiled    | (-50, 0, 50)         | (-10, 0, 20, 40)         | (0, 20)         |
#   | Moderately Soiled | (0, 50, 100)         | (20, 40, 60, 80)         | (50, 15)        |
#   | Heavily Soiled    | (50, 100, 150)       | (60, 80, 100, 110)       | (100, 20)       |
#   +-------------------+----------------------+--------------------------+-----------------+
#
# Formulas used:
#   - Triangular: μ = 0 if x ≤ a;  (x − a)/(b − a) if a < x ≤ b;  (c − x)/(c − b) if b < x < c;  0 if x ≥ c
#   - Trapezoidal: μ = 0 if x ≤ a;  (x − a)/(b − a) if a < x < b;  1 if b ≤ x ≤ c;  (d − x)/(d − c) if c < x < d;  0 if x ≥ d
#   - Gaussian: μ = e^(−(x − c)² / (2σ²)),  c = centre, σ = width
#
# Triangular membership at x = 30:
#   +-------------------+--------------------------------------------------------------+------+
#   | Fuzzy set         | Working                                                      | μ(x) |
#   +-------------------+--------------------------------------------------------------+------+
#   | Lightly Soiled    | b < x < c → μ = (c − x)/(c − b) = (50 − 30)/(50 − 0) = 20/50 | 0.40 |
#   | Moderately Soiled | a < x ≤ b → μ = (x − a)/(b − a) = (30 − 0)/(50 − 0) = 30/50  | 0.60 |
#   | Heavily Soiled    | x = 30 ≤ a = 50 → μ = 0                                      | 0.00 |
#   +-------------------+--------------------------------------------------------------+------+
#
# Trapezoidal membership at x = 30:
#   +-------------------+---------------------------------------------------------------+------+
#   | Fuzzy set         | Working                                                       | μ(x) |
#   +-------------------+---------------------------------------------------------------+------+
#   | Lightly Soiled    | c < x < d → μ = (d − x)/(d − c) = (40 − 30)/(40 − 20) = 10/20 | 0.50 |
#   | Moderately Soiled | a < x < b → μ = (x − a)/(b − a) = (30 − 20)/(40 − 20) = 10/20 | 0.50 |
#   | Heavily Soiled    | x = 30 ≤ a = 60 → μ = 0                                       | 0.00 |
#   +-------------------+---------------------------------------------------------------+------+
#
# Gaussian membership at x = 30:
#   +-------------------+----------------------------------------------------------------+------+
#   | Fuzzy set         | Working                                                        | μ(x) |
#   +-------------------+----------------------------------------------------------------+------+
#   | Lightly Soiled    | μ = e^(−(30 − 0)² / (2 × 20²)) = e^(−900/800) = e^(−1.1250)    | 0.32 |
#   | Moderately Soiled | μ = e^(−(30 − 50)² / (2 × 15²)) = e^(−400/450) = e^(−0.8889)   | 0.41 |
#   | Heavily Soiled    | μ = e^(−(30 − 100)² / (2 × 20²)) = e^(−4900/800) = e^(−6.1250) | 0.00 |
#   +-------------------+----------------------------------------------------------------+------+
#
# Result:
#   +-------------------+------------+-------------+----------+
#   | Fuzzy set         | Triangular | Trapezoidal | Gaussian |
#   +-------------------+------------+-------------+----------+
#   | Lightly Soiled    | 0.40       | 0.50        | 0.32     |
#   | Moderately Soiled | 0.60       | 0.50        | 0.41     |
#   | Heavily Soiled    | 0.00       | 0.00        | 0.00     |
#   +-------------------+------------+-------------+----------+
#   (Diagram: Membership functions (dashed line = input value) - see Google Doc)
# ======================================================================
