# Q10: Fuzzy membership functions - Room temperature
import math
import matplotlib.pyplot as plt

# Triangular: rises from a to b, falls from b to c
def triangular(x, p):
    a, b, c = p
    if x <= a or x >= c:
        return 0
    elif x <= b:
        return (x - a) / (b - a)
    else:
        return (c - x) / (c - b)

# Trapezoidal: rises a to b, flat (=1) b to c, falls c to d
def trapezoidal(x, p):
    a, b, c, d = p
    if x <= a or x >= d:
        return 0
    elif x < b:
        return (x - a) / (b - a)
    elif x <= c:
        return 1
    else:
        return (d - x) / (d - c)

# Gaussian: bell curve with centre m and width s
def gaussian(x, p):
    m, s = p
    return math.exp(-((x - m)**2) / (2 * s**2))

# Assumed values for each level
names = ["Cold", "Comfortable", "Hot"]
tri_values = [[-10, 0, 20], [10, 22, 34], [24, 40, 56]]
trap_values = [[-10, 0, 10, 20], [15, 20, 26, 31], [26, 32, 45, 50]]
gauss_values = [[5, 6], [22, 4], [38, 6]]

value = float(input("Enter Temperature (°C) (0-40): "))

print("\nTriangular memberships at", value)
for i in range(3):
    print(f"  {names[i]}: {triangular(value, tri_values[i]):.2f}")
print("\nTrapezoidal memberships at", value)
for i in range(3):
    print(f"  {names[i]}: {trapezoidal(value, trap_values[i]):.2f}")
print("\nGaussian memberships at", value)
for i in range(3):
    print(f"  {names[i]}: {gaussian(value, gauss_values[i]):.2f}")

# Plot all three types side by side
x_list = []
x = 0
while x <= 40:
    x_list.append(x)
    x = x + 0.1

titles = ["Triangular", "Trapezoidal", "Gaussian"]
plt.figure(figsize=(15, 4))
for n in range(3):
    plt.subplot(1, 3, n + 1)
    for i in range(3):
        y_list = []
        for x in x_list:
            if n == 0:
                y_list.append(triangular(x, tri_values[i]))
            elif n == 1:
                y_list.append(trapezoidal(x, trap_values[i]))
            else:
                y_list.append(gaussian(x, gauss_values[i]))
        plt.plot(x_list, y_list, label=names[i])
    plt.title(titles[n]); plt.xlabel("Temperature (°C)"); plt.ylabel("Membership")
    plt.legend(); plt.grid(True)
plt.tight_layout()
plt.show()

#python -m pip install matplotlib
# Q10: Fuzzy membership - Room temperature
# Example Input:   Enter Temperature (°C) (0-40): 28
# Example Output:
#   Triangular memberships at 28.0
#     Cold: 0.00
#     Comfortable: 0.50
#     Hot: 0.25
#
#   Trapezoidal memberships at 28.0
#     Cold: 0.00
#     Comfortable: 0.60
#     Hot: 0.33
#
#   Gaussian memberships at 28.0
#     Cold: 0.00
#     Comfortable: 0.32
#     Hot: 0.25
# (also opens a window with 3 plots)


# ======================================================================
# SOLUTION (step-by-step manual working) - Q10: Fuzzy Membership – Room Temperature
# ======================================================================
#
# Given (assumed values):
#   - Input: Temperature (°C), x = 28
#   - Membership value μ(x) is always between 0 and 1
#   +-------------+----------------------+--------------------------+-----------------+
#   | Fuzzy set   | Triangular (a, b, c) | Trapezoidal (a, b, c, d) | Gaussian (c, σ) |
#   +-------------+----------------------+--------------------------+-----------------+
#   | Cold        | (-10, 0, 20)         | (-10, 0, 10, 20)         | (5, 6)          |
#   | Comfortable | (10, 22, 34)         | (15, 20, 26, 31)         | (22, 4)         |
#   | Hot         | (24, 40, 56)         | (26, 32, 45, 50)         | (38, 6)         |
#   +-------------+----------------------+--------------------------+-----------------+
#
# Formulas used:
#   - Triangular: μ = 0 if x ≤ a;  (x − a)/(b − a) if a < x ≤ b;  (c − x)/(c − b) if b < x < c;  0 if x ≥ c
#   - Trapezoidal: μ = 0 if x ≤ a;  (x − a)/(b − a) if a < x < b;  1 if b ≤ x ≤ c;  (d − x)/(d − c) if c < x < d;  0 if x ≥ d
#   - Gaussian: μ = e^(−(x − c)² / (2σ²)),  c = centre, σ = width
#
# Triangular membership at x = 28:
#   +-------------+--------------------------------------------------------------+------+
#   | Fuzzy set   | Working                                                      | μ(x) |
#   +-------------+--------------------------------------------------------------+------+
#   | Cold        | x = 28 ≥ c = 20 → μ = 0                                      | 0.00 |
#   | Comfortable | b < x < c → μ = (c − x)/(c − b) = (34 − 28)/(34 − 22) = 6/12 | 0.50 |
#   | Hot         | a < x ≤ b → μ = (x − a)/(b − a) = (28 − 24)/(40 − 24) = 4/16 | 0.25 |
#   +-------------+--------------------------------------------------------------+------+
#
# Trapezoidal membership at x = 28:
#   +-------------+-------------------------------------------------------------+------+
#   | Fuzzy set   | Working                                                     | μ(x) |
#   +-------------+-------------------------------------------------------------+------+
#   | Cold        | x = 28 ≥ d = 20 → μ = 0                                     | 0.00 |
#   | Comfortable | c < x < d → μ = (d − x)/(d − c) = (31 − 28)/(31 − 26) = 3/5 | 0.60 |
#   | Hot         | a < x < b → μ = (x − a)/(b − a) = (28 − 26)/(32 − 26) = 2/6 | 0.33 |
#   +-------------+-------------------------------------------------------------+------+
#
# Gaussian membership at x = 28:
#   +-------------+------------------------------------------------------------+------+
#   | Fuzzy set   | Working                                                    | μ(x) |
#   +-------------+------------------------------------------------------------+------+
#   | Cold        | μ = e^(−(28 − 5)² / (2 × 6²)) = e^(−529/72) = e^(−7.3472)  | 0.00 |
#   | Comfortable | μ = e^(−(28 − 22)² / (2 × 4²)) = e^(−36/32) = e^(−1.1250)  | 0.32 |
#   | Hot         | μ = e^(−(28 − 38)² / (2 × 6²)) = e^(−100/72) = e^(−1.3889) | 0.25 |
#   +-------------+------------------------------------------------------------+------+
#
# Result:
#   +-------------+------------+-------------+----------+
#   | Fuzzy set   | Triangular | Trapezoidal | Gaussian |
#   +-------------+------------+-------------+----------+
#   | Cold        | 0.00       | 0.00        | 0.00     |
#   | Comfortable | 0.50       | 0.60        | 0.32     |
#   | Hot         | 0.25       | 0.33        | 0.25     |
#   +-------------+------------+-------------+----------+
#   (Diagram: Membership functions (dashed line = input value) - see Google Doc)
# ======================================================================
