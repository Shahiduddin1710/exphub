# Q11: Fuzzy membership functions - Traffic density
import math
import matplotlib.pyplot as plt

# Triangular: rises from a to b, falls from b to c
def triangular(x, p):
    a, b, c = p
    if x <= a or x >= c:
        return 0
    elif x <= b:
        return (x - a) / (b - a)
    else:
        return (c - x) / (c - b)

# Trapezoidal: rises a to b, flat (=1) b to c, falls c to d
def trapezoidal(x, p):
    a, b, c, d = p
    if x <= a or x >= d:
        return 0
    elif x < b:
        return (x - a) / (b - a)
    elif x <= c:
        return 1
    else:
        return (d - x) / (d - c)

# Gaussian: bell curve with centre m and width s
def gaussian(x, p):
    m, s = p
    return math.exp(-((x - m)**2) / (2 * s**2))

# Assumed values for each level
names = ["Low", "Medium", "High"]
tri_values = [[-30, 0, 30], [10, 30, 50], [30, 60, 90]]
trap_values = [[-10, 0, 10, 25], [15, 25, 35, 45], [35, 50, 60, 70]]
gauss_values = [[0, 10], [30, 8], [60, 10]]

value = float(input("Enter Traffic density (vehicles/min) (0-60): "))

print("\nTriangular memberships at", value)
for i in range(3):
    print(f"  {names[i]}: {triangular(value, tri_values[i]):.2f}")
print("\nTrapezoidal memberships at", value)
for i in range(3):
    print(f"  {names[i]}: {trapezoidal(value, trap_values[i]):.2f}")
print("\nGaussian memberships at", value)
for i in range(3):
    print(f"  {names[i]}: {gaussian(value, gauss_values[i]):.2f}")

# Plot all three types side by side
x_list = []
x = 0
while x <= 60:
    x_list.append(x)
    x = x + 0.1

titles = ["Triangular", "Trapezoidal", "Gaussian"]
plt.figure(figsize=(15, 4))
for n in range(3):
    plt.subplot(1, 3, n + 1)
    for i in range(3):
        y_list = []
        for x in x_list:
            if n == 0:
                y_list.append(triangular(x, tri_values[i]))
            elif n == 1:
                y_list.append(trapezoidal(x, trap_values[i]))
            else:
                y_list.append(gaussian(x, gauss_values[i]))
        plt.plot(x_list, y_list, label=names[i])
    plt.title(titles[n]); plt.xlabel("Traffic density (vehicles/min)"); plt.ylabel("Membership")
    plt.legend(); plt.grid(True)
plt.tight_layout()
plt.show()

#python -m pip install matplotlib
# Q11: Fuzzy membership - Traffic density
# Example Input:   Enter Traffic density (vehicles/min) (0-60): 35
# Example Output:
#   Triangular memberships at 35.0
#     Low: 0.00
#     Medium: 0.75
#     High: 0.17
#
#   Trapezoidal memberships at 35.0
#     Low: 0.00
#     Medium: 1.00
#     High: 0.00
#
#   Gaussian memberships at 35.0
#     Low: 0.00
#     Medium: 0.82
#     High: 0.04
# (also opens a window with 3 plots)


# ======================================================================
# SOLUTION (step-by-step manual working) - Q11: Fuzzy Membership – Traffic Density
# ======================================================================
#
# Given (assumed values):
#   - Input: Traffic density (vehicles/min), x = 35
#   - Membership value μ(x) is always between 0 and 1
#   +-----------+----------------------+--------------------------+-----------------+
#   | Fuzzy set | Triangular (a, b, c) | Trapezoidal (a, b, c, d) | Gaussian (c, σ) |
#   +-----------+----------------------+--------------------------+-----------------+
#   | Low       | (-30, 0, 30)         | (-10, 0, 10, 25)         | (0, 10)         |
#   | Medium    | (10, 30, 50)         | (15, 25, 35, 45)         | (30, 8)         |
#   | High      | (30, 60, 90)         | (35, 50, 60, 70)         | (60, 10)        |
#   +-----------+----------------------+--------------------------+-----------------+
#
# Formulas used:
#   - Triangular: μ = 0 if x ≤ a;  (x − a)/(b − a) if a < x ≤ b;  (c − x)/(c − b) if b < x < c;  0 if x ≥ c
#   - Trapezoidal: μ = 0 if x ≤ a;  (x − a)/(b − a) if a < x < b;  1 if b ≤ x ≤ c;  (d − x)/(d − c) if c < x < d;  0 if x ≥ d
#   - Gaussian: μ = e^(−(x − c)² / (2σ²)),  c = centre, σ = width
#
# Triangular membership at x = 35:
#   +-----------+---------------------------------------------------------------+------+
#   | Fuzzy set | Working                                                       | μ(x) |
#   +-----------+---------------------------------------------------------------+------+
#   | Low       | x = 35 ≥ c = 30 → μ = 0                                       | 0.00 |
#   | Medium    | b < x < c → μ = (c − x)/(c − b) = (50 − 35)/(50 − 30) = 15/20 | 0.75 |
#   | High      | a < x ≤ b → μ = (x − a)/(b − a) = (35 − 30)/(60 − 30) = 5/30  | 0.17 |
#   +-----------+---------------------------------------------------------------+------+
#
# Trapezoidal membership at x = 35:
#   +-----------+----------------------------------+------+
#   | Fuzzy set | Working                          | μ(x) |
#   +-----------+----------------------------------+------+
#   | Low       | x = 35 ≥ d = 25 → μ = 0          | 0.00 |
#   | Medium    | b ≤ x ≤ c (25 ≤ 35 ≤ 35) → μ = 1 | 1.00 |
#   | High      | x = 35 ≤ a = 35 → μ = 0          | 0.00 |
#   +-----------+----------------------------------+------+
#
# Gaussian membership at x = 35:
#   +-----------+--------------------------------------------------------------+------+
#   | Fuzzy set | Working                                                      | μ(x) |
#   +-----------+--------------------------------------------------------------+------+
#   | Low       | μ = e^(−(35 − 0)² / (2 × 10²)) = e^(−1225/200) = e^(−6.1250) | 0.00 |
#   | Medium    | μ = e^(−(35 − 30)² / (2 × 8²)) = e^(−25/128) = e^(−0.1953)   | 0.82 |
#   | High      | μ = e^(−(35 − 60)² / (2 × 10²)) = e^(−625/200) = e^(−3.1250) | 0.04 |
#   +-----------+--------------------------------------------------------------+------+
#
# Result:
#   +-----------+------------+-------------+----------+
#   | Fuzzy set | Triangular | Trapezoidal | Gaussian |
#   +-----------+------------+-------------+----------+
#   | Low       | 0.00       | 0.00        | 0.00     |
#   | Medium    | 0.75       | 1.00        | 0.82     |
#   | High      | 0.17       | 0.00        | 0.04     |
#   +-----------+------------+-------------+----------+
#   (Diagram: Membership functions (dashed line = input value) - see Google Doc)
# ======================================================================
