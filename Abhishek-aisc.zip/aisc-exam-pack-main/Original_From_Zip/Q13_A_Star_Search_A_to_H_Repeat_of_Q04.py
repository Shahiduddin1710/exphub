# Q13: A* Search - choose the node with the smallest f = g + h
#   g = actual cost from start till now, h = heuristic (guess) to goal

# Step 1: make the graph from edges like "A-B:2"
def make_graph(text):
    graph = {}
    for item in text.split():
        edge, cost = item.upper().split(':')
        a, b = edge.split('-')
        if a not in graph: graph[a] = []
        if b not in graph: graph[b] = []
        graph[a].append([b, int(cost)])   # undirected, so add both ways
        graph[b].append([a, int(cost)])
    return graph

# Step 2: read heuristic values like "A=5 B=4"
def read_heuristics(text):
    h = {}
    for item in text.split():
        name, value = item.upper().split('=')
        h[name] = int(value)
    return h

# Step 3: A* search
def astar(graph, h, start, goal):
    open_list = [[h[start], 0, [start]]]   # each item = [f, g, path]
    best_cost = {}
    while len(open_list) > 0:
        open_list.sort()                   # smallest f comes first
        f, g, path = open_list.pop(0)
        node = path[-1]
        if node == goal:
            print("Path:", ' -> '.join(path), "| Cost:", g)
            return
        if node in best_cost and best_cost[node] <= g:
            continue                       # already reached cheaper, skip
        best_cost[node] = g
        for next_node, cost in graph[node]:
            new_g = g + cost
            new_f = new_g + h[next_node]
            open_list.append([new_f, new_g, path + [next_node]])
    print("No path found")

graph = make_graph(input("Edges with cost: "))
h = read_heuristics(input("Heuristics: "))
start = input("Start: ").upper()
goal = input("Goal: ").upper()
astar(graph, h, start, goal)


# Q13: A* Search (A to H)
# Edges format: A-B:2 (node-node:cost), Heuristics format: A=5 B=4 ...
# Example Input:
#   Edges with cost: A-B:2 A-C:3 B-D:3 B-E:2 C-F:2 C-G:3 D-H:3 E-H:4 F-H:3 G-H:2
#   Heuristics: A=5 B=4 C=3 D=3 E=3 F=2 G=1 H=0
#   Start: A
#   Goal: H
# Example Output:
#   Path: A -> B -> D -> H | Cost: 8
# (Note: A-B-D-H, A-B-E-H, A-C-F-H and A-C-G-H all cost 8, so any one of them is a correct optimal path)


# ======================================================================
# SOLUTION (step-by-step manual working) - Q13: A* Search – A to H
# ======================================================================
#
# Given:
#   - Start = A, Goal = H
#   - A* uses f(n) = g(n) + h(n)
#   - g(n) = actual cost from start to node n,  h(n) = heuristic (estimated cost) from n to goal
#   - Always expand the node with the LOWEST f(n)
#   +------+---+---+---+---+---+---+---+---+
#   | Node | A | B | C | D | E | F | G | H |
#   +------+---+---+---+---+---+---+---+---+
#   | h(n) | 5 | 4 | 3 | 3 | 3 | 2 | 1 | 0 |
#   +------+---+---+---+---+---+---+---+---+
#
# Step-by-step working:
#   +---------------+---------------+------------------------------+--------------------------+
#   | Node expanded | Adjacent node | f(n) = g(n) + h(n)           | Selected next            |
#   +---------------+---------------+------------------------------+--------------------------+
#   | A  (g = 0)    | B             | f(B) = 2 + 4 = 6             |                          |
#   |               | C             | f(C) = 3 + 3 = 6             | B (f = 6, tie → B first) |
#   | B  (g = 2)    | D             | f(D) = (2+3) + 3 = 5 + 3 = 8 |                          |
#   |               | E             | f(E) = (2+2) + 3 = 4 + 3 = 7 | C (f = 6)                |
#   | C  (g = 3)    | F             | f(F) = (3+2) + 2 = 5 + 2 = 7 |                          |
#   |               | G             | f(G) = (3+3) + 1 = 6 + 1 = 7 | E (f = 7)                |
#   | E  (g = 4)    | H             | f(H) = (4+4) + 0 = 8         | F (f = 7)                |
#   | F  (g = 5)    | H             | f(H) = (5+3) + 0 = 8         | G (f = 7)                |
#   | G  (g = 6)    | H             | f(H) = (6+2) + 0 = 8         | D (f = 8)                |
#   | D  (g = 5)    | H             | f(H) = (5+3) + 0 = 8         | H (f = 8)                |
#   | H             | Goal found    | Cost = 8                     | STOP                     |
#   +---------------+---------------+------------------------------+--------------------------+
#
# Result:
#   - Path: A → B → D → H
#   - Cost = 2 + 3 + 3 = 8
#   - A-B-D-H, A-B-E-H, A-C-F-H and A-C-G-H all have cost 8, so all are optimal; the program prints A → B → D → H
#   (Diagram: A* graph: edge cost on lines, h inside nodes, red = path found - see Google Doc)
# ======================================================================
