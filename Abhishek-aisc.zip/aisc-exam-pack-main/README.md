# AISC Practical Exam Pack

16 experiments, each in its own folder with the program, a `HOW_TO_RUN.txt` (question, logic, code explained, inputs, expected output, viva) and a numerical-solution PDF (the sum solved on paper, same logic as the code).

**Start with `00_START_HERE.txt`** (map from exam question to folder).

## Download
```
curl -L -o aisc.zip https://github.com/Abhishek222983101/aisc-exam-pack/archive/main.zip
tar -xf aisc.zip
```

## Folders
| Folder | Contents |
|---|---|
| `Exp/` | BFS, DFS, Greedy, A*, Perceptron AND / OR / learning rates, Kohonen SOM, Fuzzy x3 |
| `MLP_Hopfield_Extra/` | MLP backpropagation x4, Hopfield network |
| `Original_From_Zip/` | the original 14 programs and solutions PDF (reference) |

Needs Python 3. matplotlib is only needed for the graphs (`python -m pip install matplotlib`).
