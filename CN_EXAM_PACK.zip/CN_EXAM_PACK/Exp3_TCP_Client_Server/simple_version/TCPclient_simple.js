const net = require('net');
const readline = require('readline');

const rl = readline.createInterface({ input: process.stdin });

const client = net.createConnection({ port: 4000, host: '127.0.0.1' }, () => {
    console.log('Connected to server');
});

client.on('data', (data) => {
    console.log('Server: ' + data.toString().trim());
});

rl.on('line', (line) => {
    client.write(line);
});

client.on('end', () => process.exit(0));
