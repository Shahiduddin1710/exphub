const net = require('net');
const readline = require('readline');

const rl = readline.createInterface({ input: process.stdin });

const server = net.createServer((socket) => {
    console.log('Client connected');

    socket.on('data', (data) => {
        console.log('Client: ' + data.toString().trim());
    });

    rl.on('line', (line) => {
        socket.write(line);
    });

    socket.on('end', () => console.log('Client disconnected'));
});

server.listen(4000, '127.0.0.1', () => {
    console.log('Server listening on port 4000');
});
