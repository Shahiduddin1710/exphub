const dgram = require('dgram');
const readline = require('readline');

const SERVER_PORT = 9876;
const SERVER_HOST = 'localhost';

const socket = dgram.createSocket('udp4');
let shuttingDown = false;

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: 'You: ',
});

function log(line) {
    readline.clearLine(process.stdout, 0);
    readline.cursorTo(process.stdout, 0);
    console.log(line);
    rl.prompt(true);
}

function shutdown() {
    if (shuttingDown) return;
    shuttingDown = true;
    socket.close();
    rl.close();
    console.log('Client shut down.');
}

socket.on('message', (msg) => {
    const message = msg.toString().trim();

    if (message.toLowerCase() === 'exit') {
        console.log('\nServer ended the chat.');
        shutdown();
        return;
    }

    log(`Server: ${message}`);
});

socket.on('error', (err) => {
    console.error(`[CLIENT] Socket error: ${err.message}`);
    shutdown();
});

console.log(`Connected to UDP Chat Server at ${SERVER_HOST}:${SERVER_PORT}`);
console.log("Type a message and press Enter. Type 'exit' to quit.");

socket.send('Hello from client', SERVER_PORT, SERVER_HOST, (err) => {
    if (err) console.error(`[CLIENT] Send error: ${err.message}`);
});
rl.prompt();

rl.on('line', (line) => {
    const outgoing = line.trim();
    if (!outgoing) {
        rl.prompt();
        return;
    }

    socket.send(outgoing, SERVER_PORT, SERVER_HOST, (err) => {
        if (err) {
            console.error(`[CLIENT] Send error: ${err.message}`);
        }
        if (outgoing.toLowerCase() === 'exit') {
            shutdown();
        } else {
            rl.prompt();
        }
    });
});

rl.on('close', shutdown);
