const dgram = require('dgram');
const readline = require('readline');

const rl = readline.createInterface({ input: process.stdin });
const client = dgram.createSocket('udp4');

client.on('message', (msg) => {
    console.log('Server: ' + msg.toString().trim());
});

client.send('Hello from client', 5000, '127.0.0.1');

rl.on('line', (line) => {
    client.send(line, 5000, '127.0.0.1');
});
