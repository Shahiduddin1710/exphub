const dgram = require('dgram');
const readline = require('readline');

const rl = readline.createInterface({ input: process.stdin });
const server = dgram.createSocket('udp4');
let clientPort;
let clientAddress;

server.on('message', (msg, rinfo) => {
    clientPort = rinfo.port;
    clientAddress = rinfo.address;
    console.log('Client: ' + msg.toString().trim());
});

rl.on('line', (line) => {
    if (clientPort) server.send(line, clientPort, clientAddress);
});

server.bind(5000, () => {
    console.log('UDP server listening on port 5000');
});
