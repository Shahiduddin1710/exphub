# CN Lab Practical Exam Pack

Computer Network lab practical (VCET, 2026-27). One folder per experiment, each with the files to open and a `HOW_TO_RUN.txt` that explains everything.

**Start with:** `CN_Lab_Reference.pdf` (one PDF with every experiment) and `00_START_HERE.txt`.

## Download
Click the green **Code** button, then **Download ZIP**, and unzip it. Or directly:
https://github.com/Abhishek222983101/cn-lab-exam-pack/archive/refs/heads/main.zip

## Folders
| Folder | Experiment |
|---|---|
| `Exp1_TCPIP_Utility_Commands` | TCP/IP utility commands (Windows cmd) |
| `Exp2a_Ring_Topology` | Ring topology |
| `Exp2b_Bus_Topology` | Bus topology |
| `Exp2c_Mesh_Topology` | Mesh topology |
| `Exp2d_Star_Ring_Topology` | Star-Ring topology |
| `Exp2e_Bus_Ring_Topology` | Bus-Ring topology |
| `Exp2f_Star_Topology` | Star topology (hub and switch files) |
| `Exp2g_Hybrid_Topology` | Hybrid topology (star + bus) |
| `Exp3_TCP_Client_Server` | TCP client-server (Node.js) |
| `Exp4_UDP_Client_Server` | UDP client-server (Node.js) |

## Tested
- All eight Packet Tracer files open and ping in Packet Tracer 7.2.2 (32-bit).
- TCP and UDP programs (simple and full versions) exchange messages both ways. Needs Node.js (`node -v`).
- Windows command outputs are samples; run them on a Windows PC.
