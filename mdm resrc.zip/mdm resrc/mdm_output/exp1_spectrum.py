# Exp 1: EM spectrum & wireless bands (log scale)
import matplotlib.pyplot as plt
bands = [("VLF", 3e3, 3e4, "Submarine"), ("LF", 3e4, 3e5, "Navigation"), ("MF", 3e5, 3e6, "AM Radio"),
         ("HF", 3e6, 3e7, "Shortwave"), ("VHF", 3e7, 3e8, "FM, TV"), ("UHF", 3e8, 3e9, "GSM, 4G, BT"),
         ("SHF", 3e9, 3e10, "Wi-Fi 5G, Sat"), ("EHF", 3e10, 3e11, "5G mmWave"), ("Infrared", 3e11, 4e14, "Remote"),
         ("Visible", 4e14, 8e14, "Light"), ("UV", 8e14, 3e16, "Sterilise"), ("X-ray", 3e16, 3e19, "Medical"),
         ("Gamma", 3e19, 1e21, "Nuclear")]
plt.figure(figsize=(12, 3.5)); plt.xscale("log")
for i, (n, a, b, u) in enumerate(bands):
    plt.barh(0, b - a, left=a, color=plt.cm.rainbow(i / 13), edgecolor="k")
    plt.text((a * b) ** 0.5, 0, n + "\n" + u, ha="center", va="center", rotation=90, fontsize=7)
plt.xlim(1e3, 1e21); plt.yticks([]); plt.xlabel("Frequency (Hz) - log scale"); plt.title("EM Spectrum & Wireless Bands")
plt.tight_layout(); plt.savefig("exp1_spectrum.png"); plt.show()
