# Exp 2: Frequency reuse. Change i, j -> N = i^2 + i*j + j^2, D/R = sqrt(3N)
import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import RegularPolygon
i, j = 2, 1
N = i*i + i*j + j*j
cells, keys = [], {}
for q in range(-8, 9):
    for r in range(-8, 9):
        x, y = np.sqrt(3) * (q + r / 2), 1.5 * r                     # hexagon centre
        if np.hypot(x, y) > 8: continue
        k = ((q*(i+j) + r*j) % N, (r*i - q*j) % N)                   # same k = same frequency
        c = keys.setdefault(k, len(keys)); cells.append((x, y, c))
        plt.gca().add_patch(RegularPolygon((x, y), 6, radius=1, fc=plt.cm.gist_rainbow(c / N), ec="k"))
        plt.text(x, y, "F%d" % (c + 1), ha="center", va="center", fontsize=7)
x0, y0, c0 = [c for c in cells if c[:2] == (0, 0)][0]
x1, y1, _ = min((c for c in cells if c[2] == c0 and c[:2] != (x0, y0)), key=lambda c: np.hypot(c[0]-x0, c[1]-y0))
D = np.hypot(x1 - x0, y1 - y0)
plt.plot([x0, x1], [y0, y1], "k-", lw=3)
plt.title("i=%d j=%d  N=%d  D=%.2fR  D/R=sqrt(3N)=%.2f" % (i, j, N, D, np.sqrt(3 * N)))
plt.xlim(-9, 9); plt.ylim(-9, 9); plt.gca().set_aspect("equal"); plt.axis("off")
plt.savefig("exp2_reuse.png"); plt.show()
print("i=%d j=%d N=%d D/R=%.2f each cell gets 1/%d of channels" % (i, j, N, D, N))
