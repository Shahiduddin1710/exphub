# Exp 7: Multipath fading - 20 reflected paths, receiver moves 5 m at 900 MHz
import numpy as np, matplotlib.pyplot as plt
np.random.seed(1)
lam = 3e8 / 900e6; d = np.linspace(0, 5, 1000); P = 20
a, ph, ang = np.random.rand(P), 2*np.pi*np.random.rand(P), 2*np.pi*np.random.rand(P)
h = sum(a[k] * np.exp(1j * (ph[k] + 2*np.pi*d/lam*np.cos(ang[k]))) for k in range(P))
db = 20 * np.log10(abs(h) / abs(h).mean())                           # dB relative to mean
plt.plot(d, db); plt.axhline(-10, color="r", ls="--", label="deep fade (-10 dB)")
plt.xlabel("Distance moved (m)"); plt.ylabel("Signal level (dB)"); plt.grid(alpha=.3); plt.legend()
plt.title("Multipath Fading"); plt.savefig("exp7_multipath.png"); plt.show()
print("Max %.1f dB at %.2f m | Min %.1f dB at %.2f m | below -10 dB: %.1f%%" %
      (db.max(), d[db.argmax()], db.min(), d[db.argmin()], 100 * (db < -10).mean()))
