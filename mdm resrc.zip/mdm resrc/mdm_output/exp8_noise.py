# Exp 8: BER vs SNR for BPSK with noise only and noise + interference
import numpy as np, matplotlib.pyplot as plt
np.random.seed(0); N = 200000
bits = np.random.randint(0, 2, N); s = 2 * bits - 1                  # BPSK: 0 -> -1, 1 -> +1
def ber(snr, sir=None):
    r = s + np.random.randn(N) / np.sqrt(2 * 10**(snr / 10))         # add noise
    if sir: r += 10**(-sir / 20) * np.sign(np.random.randn(N))       # add interference
    return np.mean((r > 0) != bits)
snr = range(11)
for sir, m, t in [(None, "o-", "Noise only"), (6, "s-", "Noise + interference (SIR 6 dB)"), (3, "^-", "Noise + interference (SIR 3 dB)")]:
    y = [ber(x, sir) for x in snr]; plt.semilogy(snr, np.array(y) + 1e-6, m, label=t)
    print("%-32s BER at 10 dB = %.1e" % (t, y[-1]))
plt.xlabel("SNR (dB)"); plt.ylabel("Bit Error Rate"); plt.grid(alpha=.3, which="both"); plt.legend()
plt.title("Effect of Noise & Interference on BER"); plt.savefig("exp8_noise.png"); plt.show()
